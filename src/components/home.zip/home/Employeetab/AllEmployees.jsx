import React, { useState } from "react";
import { FiPlusCircle, FiEdit, FiTrash2 } from "react-icons/fi";
import uncheckbox from "../../../assets/employee/checkbox/uncheck.png";
import checkbox from "../../../assets/employee/checkbox/checkbox.png";

const sampleData = [
  {
    id: 1,
    dp: "https://via.placeholder.com/40",
    name: "John Doe",
    email: "john@example.com",
    phone: "123-456-7890",
    employeeId: "EMP001",
    joiningDate: "2023-01-01",
    role: "Developer",
  },
  {
    id: 2,
    dp: "https://via.placeholder.com/40",
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "098-765-4321",
    employeeId: "EMP002",
    joiningDate: "2023-02-01",
    role: "Designer",
  },
  // Add more sample data as needed
];

function AllEmployees() {
  const [isChecked, setIsChecked] = useState({});
  const [headerChecked, setHeaderChecked] = useState(false);

  const handleCheckboxChange = (id) => {
    setIsChecked((prevState) => ({
      ...prevState,
      [id]: !prevState[id],
    }));
  };

  const handleHeaderCheckboxChange = () => {
    const newCheckedState = !headerChecked;
    setHeaderChecked(newCheckedState);

    const newIsChecked = {};
    sampleData.forEach((employee) => {
      newIsChecked[employee.id] = newCheckedState;
    });
    setIsChecked(newIsChecked);
  };

  return (
    <>
      <div id="main" className="h-screen w-screen bg-[#dbf2ff] p-4">
        <div className="ml-5 ">
          <p className="text-[#e65f2b] font-semibold">Employees/AllEmployees</p>
        </div>

        <div className="flex justify-end mb-4">
          <div
            id="addemployee"
            className="w-auto inline-block bg-[#0098f1] h-[48px] rounded-lg justify-end items-center"
          >
            <button
              type="button"
              className="flex justify-center items-center w-[186px] h-[48px] text-white"
            >
              <FiPlusCircle className="text-2xl font-bold mr-2" /> Add Employee
            </button>
          </div>
        </div>
        <div id="table" className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b bg-[#dbf2ff] text-center">
                  <img
                    src={headerChecked ? checkbox : uncheckbox}
                    alt="Header Checkbox"
                    onClick={handleHeaderCheckboxChange}
                  />
                </th>
                <th className="py-2 px-4 border-b bg-[#dbf2ff]"></th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Name
                </th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Email-id
                </th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Phone
                </th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Employee ID
                </th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Joining Date
                </th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Role
                </th>
                <th className="py-2 px-4 border-b bg-[#0098f1] bg-opacity-30 text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {sampleData.map((employee) => (
                <tr key={employee.id} className="bg-[#dbf2ff]">
                  <td className="py-2 px-4 border-b text-center">
                    <img
                      src={isChecked[employee.id] ? checkbox : uncheckbox}
                      alt="Checkbox"
                      onClick={() => handleCheckboxChange(employee.id)}
                    />
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    <img
                      src={employee.dp}
                      alt="DP"
                      className="w-10 h-10 rounded-full"
                    />
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {employee.name}
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {employee.email}
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {employee.phone}
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {employee.employeeId}
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {employee.joiningDate}
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {employee.role}
                  </td>
                  <td className="py-2 px-4 border-b text-center flex items-center space-x-2">
                    <button className="text-blue-500 flex py-3 items-center">
                      <FiEdit className="mr-1" />
                    </button>
                    <button className="text-red-500 flex py-3 items-center">
                      <FiTrash2 className="mr-1" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default AllEmployees;
